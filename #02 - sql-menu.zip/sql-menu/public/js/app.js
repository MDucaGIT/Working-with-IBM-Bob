// =============================================================================
// public/js/app.js  - Main screen logic
// =============================================================================

'use strict';

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------
let currentUser    = '';
let settings       = { editorFont: 'Consolas', editorSize: 14, gridFont: 'Consolas', gridSize: 13 };
let tabulatorGrid  = null;
let queryRunning   = false;
let pendingVarsSql = '';   // SQL waiting for variable substitution

// ---------------------------------------------------------------------------
// Init
// ---------------------------------------------------------------------------
document.addEventListener('DOMContentLoaded', async () => {
  // Check session
  try {
    const me = await apiFetch('/api/auth/me');
    currentUser = me.user;
    document.getElementById('navUser').textContent = currentUser;
  } catch (_) {
    window.location.href = '/login.html';
    return;
  }

  await loadSettings();
  await loadSideMenu();
  bindEvents();
});

// ---------------------------------------------------------------------------
// API helpers
// ---------------------------------------------------------------------------
async function apiFetch(url, opts = {}) {
  const resp = await fetch(url, {
    headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) },
    ...opts,
  });
  if (!resp.ok) {
    const body = await resp.json().catch(() => ({}));
    throw new Error(body.error || `HTTP ${resp.status}`);
  }
  return resp.json();
}

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------
async function loadSettings() {
  try {
    settings = await apiFetch('/api/settings');
  } catch (_) { /* use defaults */ }
  applySettings();
}

function applySettings() {
  const editor = document.getElementById('sqlEditor');
  if (editor) {
    editor.style.fontFamily = settings.editorFont;
    editor.style.fontSize   = settings.editorSize + 'px';
  }
  if (tabulatorGrid) {
    document.querySelectorAll('#resultsGrid .tabulator-cell, #resultsGrid .tabulator-col-title')
      .forEach(el => {
        el.style.fontFamily = settings.gridFont;
        el.style.fontSize   = settings.gridSize + 'px';
      });
  }
}

function populateSettingsModal() {
  setSelectValue('setEditorFont', settings.editorFont);
  setSelectValue('setEditorSize', String(settings.editorSize));
  setSelectValue('setGridFont',   settings.gridFont);
  setSelectValue('setGridSize',   String(settings.gridSize));
}

function setSelectValue(id, value) {
  const sel = document.getElementById(id);
  if (!sel) return;
  for (const opt of sel.options) {
    if (opt.value === value) { opt.selected = true; return; }
  }
}

// ---------------------------------------------------------------------------
// Side menu
// ---------------------------------------------------------------------------
async function loadSideMenu() {
  const container = document.getElementById('userMenusList');
  container.innerHTML = '';
  try {
    const menus = await apiFetch('/api/menus');
    for (const menu of menus) {
      const wrapper = document.createElement('div');
      wrapper.className = 'mb-1';

      const hdr = document.createElement('div');
      hdr.className = 'user-menu-header';
      hdr.innerHTML = `<span>${menu.MHDESC}</span><i class="bi bi-chevron-right menu-chev"></i>`;

      const items = document.createElement('div');
      items.className = 'user-menu-items';
      items.style.display = 'none';

      hdr.addEventListener('click', async () => {
        const isOpen = items.style.display !== 'none';
        if (isOpen) {
          items.style.display = 'none';
          hdr.querySelector('.menu-chev').className = 'bi bi-chevron-right menu-chev';
        } else {
          if (items.childElementCount === 0) {
            await populateMenuItems(items, menu.MHID);
          }
          items.style.display = 'block';
          hdr.querySelector('.menu-chev').className = 'bi bi-chevron-down menu-chev';
        }
      });

      wrapper.appendChild(hdr);
      wrapper.appendChild(items);
      container.appendChild(wrapper);
    }
  } catch (err) {
    container.innerHTML = `<small class="text-danger px-2">${err.message}</small>`;
  }
}

async function populateMenuItems(container, menuId) {
  try {
    const menu = await apiFetch(`/api/menus/${menuId}`);
    for (const item of (menu.items || [])) {
      const btn = document.createElement('button');
      btn.className   = 'script-btn';
      btn.textContent = item.SHDESC;
      btn.title       = item.SHDSCL || '';
      btn.addEventListener('click', () => loadScriptIntoEditor(item.MDSTID));
      container.appendChild(btn);
    }
  } catch (err) {
    container.innerHTML = `<small class="text-danger">${err.message}</small>`;
  }
}

async function loadScriptIntoEditor(scriptId) {
  try {
    const script = await apiFetch(`/api/scripts/${scriptId}`);
    document.getElementById('sqlEditor').value = script.SDSTMT || '';
    // Close side panel
    document.getElementById('sidePanel').classList.remove('open');
  } catch (err) {
    alert('Error loading script: ' + err.message);
  }
}

// ---------------------------------------------------------------------------
// Query execution
// ---------------------------------------------------------------------------
function extractVariables(sql) {
  const re = /:([A-Za-z_][A-Za-z0-9_]*)/g;
  const vars = [];
  let m;
  while ((m = re.exec(sql)) !== null) {
    if (!vars.includes(m[1])) vars.push(m[1]);
  }
  return vars;
}

async function executeQuery(sql) {
  hideStatusMessage();
  const maxRows = parseInt(document.getElementById('maxRowsInput').value) || 200;
  setRunning(true);

  try {
    const result = await apiFetch('/api/query/execute', {
      method: 'POST',
      body:   JSON.stringify({ sql, maxRows }),
    });
    if (result.columns.length === 0 && result.updateCount !== null) {
      // DML statement (INSERT/UPDATE/DELETE): show affected rows, hide grid
      showStatusMessage(`Statement executed successfully. Rows affected: ${result.updateCount}`, 'success');
      document.getElementById('resultsCard').style.display = 'none';
    } else {
      renderGrid(result.columns, result.rows);
      document.getElementById('rowCountBadge').textContent = `${result.rowCount} row${result.rowCount !== 1 ? 's' : ''}`;
      document.getElementById('resultsCard').style.display = 'block';
    }
  } catch (err) {
    alert('Query error: ' + err.message);
  } finally {
    setRunning(false);
  }
}

function setRunning(running) {
  queryRunning = running;
  document.getElementById('btnExecute').disabled = running;
  document.getElementById('btnStop').disabled    = !running;
}

function showStatusMessage(msg, type = 'warning') {
  const el = document.getElementById('statusMsg');
  el.className   = `alert alert-${type} alert-dismissible mb-0`;
  el.innerHTML   = `${msg}<button type="button" class="btn-close" onclick="this.parentElement.style.display='none'"></button>`;
  el.style.display = 'block';
}

function hideStatusMessage() {
  document.getElementById('statusMsg').style.display = 'none';
}

// ---------------------------------------------------------------------------
// Grid rendering (Tabulator)
// ---------------------------------------------------------------------------

// Detect whether a column contains numeric data by sampling the first non-null rows
function detectSorter(rows, col) {
  for (const row of rows.slice(0, 20)) {
    const v = row[col];
    if (v === null || v === undefined || v === '') continue;
    return isNaN(Number(v)) ? 'string' : 'number';
  }
  return 'string';
}

function renderGrid(columns, rows) {
  // Build column definitions
  const colDefs = [
    {
      title: '#', field: '__rowNum', width: 50, frozen: true,
      resizable: false, headerSort: false,
      formatter: (cell) => {
        const el = document.createElement('span');
        el.className = 'row-num-cell';
        el.textContent = cell.getRow().getPosition();
        return el;
      },
    },
    ...columns.map(col => ({
      title:              col,
      field:              col,
      headerSort:         true,
      resizable:          true,
      sorter:             detectSorter(rows, col),
      // Tristate sort: asc → desc → none
      headerSortTristate: true,
    })),
  ];

  // Add row number to data
  const tableData = rows.map((r, i) => ({ __rowNum: i + 1, ...r }));

  if (tabulatorGrid) {
    tabulatorGrid.destroy();
  }

  tabulatorGrid = new Tabulator('#resultsGrid', {
    data:                    tableData,
    columns:                 colDefs,
    layout:                  'fitDataFill',
    movableColumns:          true,
    selectableRows:          true,
    selectableRowsRangeMode: 'click',
    height:                  '400px',
    rowFormatter:      (row) => {
      const cells = row.getCells();
      cells.forEach(c => {
        c.getElement().style.fontFamily = settings.gridFont;
        c.getElement().style.fontSize   = settings.gridSize + 'px';
      });
    },
  });

  // Sync top scroll bar with grid scroll
  setTimeout(() => {
    const gridEl    = document.querySelector('#resultsGrid .tabulator-tableholder');
    const scrollTop = document.getElementById('gridScrollTop');
    const inner     = document.getElementById('gridScrollTopInner');
    if (gridEl) {
      inner.style.width = gridEl.scrollWidth + 'px';
      scrollTop.addEventListener('scroll', () => { gridEl.scrollLeft = scrollTop.scrollLeft; });
      gridEl.addEventListener('scroll',   () => { scrollTop.scrollLeft = gridEl.scrollLeft; });
    }
  }, 300);
}

// ---------------------------------------------------------------------------
// Ctrl+C copy selected rows
// ---------------------------------------------------------------------------
document.addEventListener('keydown', (e) => {
  if (e.ctrlKey && e.key === 'c' && tabulatorGrid) {
    const selectedRows = tabulatorGrid.getSelectedRows();
    if (selectedRows.length === 0) return;
    const cols   = tabulatorGrid.getColumns()
                     .filter(c => c.getField() !== '__rowNum')
                     .map(c => c.getField());
    const header = cols.join('\t');
    const rows   = selectedRows.map(row => cols.map(c => row.getData()[c] ?? '').join('\t'));
    const text   = [header, ...rows].join('\n');

    // navigator.clipboard requires HTTPS; fall back to execCommand on plain HTTP
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).catch(() => copyViaExecCommand(text));
    } else {
      copyViaExecCommand(text);
    }
    e.preventDefault();
  }
});

function copyViaExecCommand(text) {
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.style.cssText = 'position:fixed;top:-9999px;left:-9999px;opacity:0';
  document.body.appendChild(ta);
  ta.focus();
  ta.select();
  try { document.execCommand('copy'); } catch (_) {}
  document.body.removeChild(ta);
}

// ---------------------------------------------------------------------------
// Event bindings
// ---------------------------------------------------------------------------
function bindEvents() {
  // Navbar
  document.getElementById('btnMenu').addEventListener('click', () => {
    document.getElementById('sidePanel').classList.toggle('open');
  });
  document.getElementById('btnClosePanel').addEventListener('click', () => {
    document.getElementById('sidePanel').classList.remove('open');
  });
  document.getElementById('btnLogout').addEventListener('click', async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    window.location.href = '/login.html';
  });

  // Settings modal
  const settingsModal = new bootstrap.Modal(document.getElementById('settingsModal'));
  document.getElementById('btnSettings').addEventListener('click', () => {
    populateSettingsModal();
    settingsModal.show();
  });
  document.getElementById('btnSaveSettings').addEventListener('click', async () => {
    settings = {
      editorFont: document.getElementById('setEditorFont').value,
      editorSize: parseInt(document.getElementById('setEditorSize').value),
      gridFont:   document.getElementById('setGridFont').value,
      gridSize:   parseInt(document.getElementById('setGridSize').value),
    };
    applySettings();
    try {
      await apiFetch('/api/settings', { method: 'POST', body: JSON.stringify(settings) });
    } catch (_) { /* non-critical */ }
    settingsModal.hide();
  });

  // Config accordion in side panel
  document.getElementById('configAccordionBtn').addEventListener('click', () => {
    const items   = document.getElementById('configItems');
    const chevron = document.getElementById('configChevron');
    const isOpen  = items.style.display !== 'none';
    items.style.display   = isOpen ? 'none' : 'block';
    chevron.className     = isOpen ? 'bi bi-chevron-right' : 'bi bi-chevron-down';
  });

  // Execute button
  document.getElementById('btnExecute').addEventListener('click', () => {
    const sql  = document.getElementById('sqlEditor').value.trim();
    if (!sql)  { alert('Please enter a SQL statement.'); return; }
    const vars = extractVariables(sql);
    if (vars.length > 0) {
      showVarsModal(sql, vars);
    } else {
      executeQuery(sql);
    }
  });

  // Stop button
  document.getElementById('btnStop').addEventListener('click', async () => {
    try {
      await apiFetch('/api/query/cancel', { method: 'POST' });
      showStatusMessage('Query stopped.', 'warning');
    } catch (err) {
      alert('Could not cancel query: ' + err.message);
    } finally {
      setRunning(false);
    }
  });
}

// ---------------------------------------------------------------------------
// Variables modal
// ---------------------------------------------------------------------------
const varsModal = new bootstrap.Modal(document.getElementById('varsModal'));

function showVarsModal(sql, vars) {
  pendingVarsSql = sql;
  const body = document.getElementById('varsModalBody');
  body.innerHTML = '';
  for (const v of vars) {
    const label = document.createElement('label');
    label.className   = 'form-label fw-semibold';
    label.textContent = ':' + v;
    const input = document.createElement('input');
    input.type        = 'text';
    input.className   = 'form-control mb-3';
    input.dataset.var = v;
    input.placeholder = `Value for :${v}`;
    body.appendChild(label);
    body.appendChild(input);
  }
  varsModal.show();
  // Focus first input
  setTimeout(() => { const f = body.querySelector('input'); if (f) f.focus(); }, 300);
}

document.getElementById('btnRunWithVars').addEventListener('click', () => {
  let sql = pendingVarsSql;
  const inputs = document.querySelectorAll('#varsModalBody input[data-var]');
  for (const inp of inputs) {
    const name  = inp.dataset.var;
    const value = inp.value;   // user provides value exactly as needed (quotes can be in the script or here)
    // Replace all occurrences of :varname (case-insensitive)
    sql = sql.replace(new RegExp(':' + name, 'gi'), value);
  }
  varsModal.hide();
  executeQuery(sql);
});
