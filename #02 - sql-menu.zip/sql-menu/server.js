// =============================================================================
// server.js - Main Express server entry point
// =============================================================================

'use strict';

const express        = require('express');
const session        = require('express-session');
const path           = require('path');
const config         = require('./config');

const authRouter     = require('./routes/auth');
const queryRouter    = require('./routes/query');
const scriptsRouter  = require('./routes/scripts');
const menusRouter    = require('./routes/menus');
const settingsRouter = require('./routes/settings');

const app = express();

// ---------------------------------------------------------------------------
// Middleware  (session must be registered before routes and static guard)
// ---------------------------------------------------------------------------
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: false }));
app.use(session(config.session));

// Serve static assets (CSS, JS, images) but NOT html pages via this handler
app.use(express.static(path.join(__dirname, 'public'), { index: false }));

// ---------------------------------------------------------------------------
// Auth-guarded HTML pages
// ---------------------------------------------------------------------------
function guardedPage(page) {
  return (req, res) => {
    if (req.session && req.session.user) {
      res.sendFile(path.join(__dirname, 'public', page));
    } else {
      res.redirect('/login.html');
    }
  };
}

app.get('/',                  guardedPage('index.html'));
app.get('/index.html',        guardedPage('index.html'));
app.get('/manage-scripts.html', guardedPage('manage-scripts.html'));
app.get('/manage-menus.html',   guardedPage('manage-menus.html'));

// Login page — always accessible
app.get('/login.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// ---------------------------------------------------------------------------
// API Routes
// ---------------------------------------------------------------------------
app.use('/api/auth',     authRouter);
app.use('/api/query',    queryRouter);
app.use('/api/scripts',  scriptsRouter);
app.use('/api/menus',    menusRouter);
app.use('/api/settings', settingsRouter);

// ---------------------------------------------------------------------------
// Start
// ---------------------------------------------------------------------------
const PORT = config.server.port;
app.listen(PORT, () => {
  console.log(`sql-menu running on port ${PORT}`);
});
