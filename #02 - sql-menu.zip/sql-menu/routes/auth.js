// =============================================================================
// routes/auth.js - Login / logout endpoints
// POST /api/auth/login   { user, password }
// POST /api/auth/logout
// GET  /api/auth/me      -> { user }
// =============================================================================

'use strict';

const express = require('express');
const { SQLJob } = require('@ibm/mapepire-js');
const config  = require('../config');

const router = express.Router();

// ---------------------------------------------------------------------------
// POST /api/auth/login
// Opens a Mapepire connection to validate credentials against IBM i.
// The connection is kept alive in the session for subsequent queries.
// ---------------------------------------------------------------------------
router.post('/login', async (req, res) => {
  const { user, password } = req.body;

  if (!user || !password) {
    return res.status(400).json({ error: 'Missing credentials' });
  }

  try {
    const job = new SQLJob({
      naming:        'sql',
      'date format': 'iso',   // dates returned as YYYY-MM-DD
    });
    await job.connect({
      host:               config.mapepire.host,
      port:               config.mapepire.port,
      user:               user.trim().toUpperCase(),
      password:           password,
      verifyHostName:     false,
      rejectUnauthorized: !config.mapepire.ignoreUnauthorized,
    });

    // Store serialisable session data; the live job is kept in a server-side map
    const userKey = user.trim().toUpperCase();
    req.session.user = userKey;

    // Keep the SQLJob instance in a process-level map keyed by session id
    global.sessionJobs = global.sessionJobs || {};
    global.sessionJobs[req.session.id] = job;

    // Save connect options on the job so cancel/reconnect can reuse them
    job._connectOptions = {
      host:               config.mapepire.host,
      port:               config.mapepire.port,
      user:               userKey,
      password:           password,
      verifyHostName:     false,
      rejectUnauthorized: !config.mapepire.ignoreUnauthorized,
    };

    return res.json({ user: userKey });
  } catch (err) {
    // Return a generic message regardless of the actual IBM i error
    console.error('Login error:', err.message);
    return res.status(401).json({ error: 'Invalid username or password' });
  }
});

// ---------------------------------------------------------------------------
// POST /api/auth/logout
// ---------------------------------------------------------------------------
router.post('/logout', async (req, res) => {
  const job = global.sessionJobs && global.sessionJobs[req.session.id];
  if (job) {
    try { await job.close(); } catch (_) { /* ignore */ }
    delete global.sessionJobs[req.session.id];
  }
  req.session.destroy(() => {
    res.json({ ok: true });
  });
});

// ---------------------------------------------------------------------------
// GET /api/auth/me
// ---------------------------------------------------------------------------
router.get('/me', (req, res) => {
  if (req.session && req.session.user) {
    return res.json({ user: req.session.user });
  }
  return res.status(401).json({ error: 'Not authenticated' });
});

module.exports = router;
