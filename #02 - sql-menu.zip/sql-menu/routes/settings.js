// =============================================================================
// routes/settings.js - Per-user settings stored as JSON files on the IFS
//
// GET  /api/settings   -> { editorFont, editorSize, gridFont, gridSize }
// POST /api/settings   -> save settings
// =============================================================================

'use strict';

const express = require('express');
const fs      = require('fs');
const path    = require('path');
const config  = require('../config');
const router  = express.Router();

function requireAuth(req, res, next) {
  if (!req.session || !req.session.user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  next();
}
router.use(requireAuth);

const SETTINGS_DIR = path.join(config.appBasePath, 'settings');

const DEFAULTS = {
  editorFont: 'Consolas',
  editorSize: 14,
  gridFont:   'Consolas',
  gridSize:   13,
};

function settingsFilePath(user) {
  return path.join(SETTINGS_DIR, `${user.trim()}.json`);
}

// ---------------------------------------------------------------------------
// GET /api/settings
// ---------------------------------------------------------------------------
router.get('/', (req, res) => {
  const filePath = settingsFilePath(req.session.user);
  try {
    if (fs.existsSync(filePath)) {
      const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      return res.json({ ...DEFAULTS, ...data });
    }
    return res.json(DEFAULTS);
  } catch (err) {
    return res.json(DEFAULTS);
  }
});

// ---------------------------------------------------------------------------
// POST /api/settings
// ---------------------------------------------------------------------------
router.post('/', (req, res) => {
  const { editorFont, editorSize, gridFont, gridSize } = req.body;

  const data = {
    editorFont: editorFont || DEFAULTS.editorFont,
    editorSize: parseInt(editorSize) || DEFAULTS.editorSize,
    gridFont:   gridFont   || DEFAULTS.gridFont,
    gridSize:   parseInt(gridSize)   || DEFAULTS.gridSize,
  };

  try {
    if (!fs.existsSync(SETTINGS_DIR)) {
      fs.mkdirSync(SETTINGS_DIR, { recursive: true });
    }
    fs.writeFileSync(settingsFilePath(req.session.user), JSON.stringify(data, null, 2), 'utf8');
    return res.json({ ok: true });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

module.exports = router;
