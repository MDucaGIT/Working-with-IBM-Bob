// =============================================================================
// routes/scripts.js - Manage saved SQL scripts
//
// GET    /api/scripts          -> list all scripts for the logged-in user
// GET    /api/scripts/:id      -> get one script (header + body)
// POST   /api/scripts          -> create new script  { desc, dscl, stmt }
// PUT    /api/scripts/:id      -> update script      { desc, dscl, stmt }
// DELETE /api/scripts/:id      -> soft-delete script
// =============================================================================

'use strict';

const express = require('express');
const config  = require('../config');
const router  = express.Router();

const LIB = config.db.library;

function requireAuth(req, res, next) {
  if (!req.session || !req.session.user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  next();
}
router.use(requireAuth);

// Helper: get the SQLJob for this session
function getJob(req) {
  return global.sessionJobs && global.sessionJobs[req.session.id];
}

// Helper: run a single SQL statement through the session job
async function runSql(job, sql) {
  const q = job.query(sql);
  const r = await q.execute(10000);
  await q.close();
  return r;
}

// ---------------------------------------------------------------------------
// GET /api/scripts  - list scripts (header only, active)
// ---------------------------------------------------------------------------
router.get('/', async (req, res) => {
  const job  = getJob(req);
  if (!job) return res.status(401).json({ error: 'Session expired' });
  const user = req.session.user.padEnd(10);

  try {
    const sql = `SELECT SHID, TRIM(SHDESC) AS SHDESC, SHDSCL, SHCRTS, SHMDTS `
              + `FROM ${LIB}.SQLHD00F `
              + `WHERE SHUSER = '${user}' AND SHANNL = ' ' `
              + `ORDER BY SHDESC`;
    const result = await runSql(job, sql);
    return res.json(result.data || []);
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// GET /api/scripts/:id  - get one script with its body
// ---------------------------------------------------------------------------
router.get('/:id', async (req, res) => {
  const job  = getJob(req);
  if (!job) return res.status(401).json({ error: 'Session expired' });
  const user = req.session.user.padEnd(10);
  const id   = req.params.id;

  try {
    const sqlHd = `SELECT SHID, TRIM(SHDESC) AS SHDESC, SHDSCL `
                + `FROM ${LIB}.SQLHD00F `
                + `WHERE SHUSER = '${user}' AND SHID = '${id}' AND SHANNL = ' '`;
    const sqlDt = `SELECT SDSTMT `
                + `FROM ${LIB}.SQLDT00F `
                + `WHERE SDUSER = '${user}' AND SDID = '${id}'`;

    const [hd, dt] = await Promise.all([runSql(job, sqlHd), runSql(job, sqlDt)]);
    if (!hd.data || hd.data.length === 0) {
      return res.status(404).json({ error: 'Script not found' });
    }
    return res.json({ ...hd.data[0], SDSTMT: dt.data && dt.data[0] ? dt.data[0].SDSTMT : '' });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// POST /api/scripts  - create new script
// ---------------------------------------------------------------------------
router.post('/', async (req, res) => {
  const job  = getJob(req);
  if (!job) return res.status(401).json({ error: 'Session expired' });
  const user = req.session.user.padEnd(10);
  const { desc, dscl, stmt } = req.body;

  if (!desc || !desc.trim()) return res.status(400).json({ error: 'Short description required' });

  try {
    // Generate next ID using sequence
    const seqResult = await runSql(job, `VALUES (NEXT VALUE FOR ${LIB}.SQLSEQ)`);
    const seqNum    = seqResult.data[0]['00001'];
    const newId     = 'S' + String(seqNum).padStart(9, '0');

    const safeDscl = (dscl || '').replace(/'/g, "''");
    const safeDesc = desc.trim().substring(0, 30).replace(/'/g, "''");
    const safeStmt = (stmt || '').replace(/'/g, "''");
    const now      = 'CURRENT_TIMESTAMP';

    await runSql(job,
      `INSERT INTO ${LIB}.SQLHD00F (SHUSER, SHID, SHDESC, SHDSCL, SHCRTS, SHMDTS, SHANNL) `
      + `VALUES ('${user}', '${newId}', '${safeDesc}', '${safeDscl}', ${now}, ${now}, ' ')`
    );
    await runSql(job,
      `INSERT INTO ${LIB}.SQLDT00F (SDUSER, SDID, SDSTMT, SDCRTS, SDMDTS) `
      + `VALUES ('${user}', '${newId}', '${safeStmt}', ${now}, ${now})`
    );

    return res.status(201).json({ id: newId });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// PUT /api/scripts/:id  - update script
// ---------------------------------------------------------------------------
router.put('/:id', async (req, res) => {
  const job  = getJob(req);
  if (!job) return res.status(401).json({ error: 'Session expired' });
  const user = req.session.user.padEnd(10);
  const id   = req.params.id;
  const { desc, dscl, stmt } = req.body;

  if (!desc || !desc.trim()) return res.status(400).json({ error: 'Short description required' });

  try {
    const safeDesc = desc.trim().substring(0, 30).replace(/'/g, "''");
    const safeDscl = (dscl || '').replace(/'/g, "''");
    const safeStmt = (stmt || '').replace(/'/g, "''");
    const now      = 'CURRENT_TIMESTAMP';

    await runSql(job,
      `UPDATE ${LIB}.SQLHD00F SET SHDESC = '${safeDesc}', SHDSCL = '${safeDscl}', SHMDTS = ${now} `
      + `WHERE SHUSER = '${user}' AND SHID = '${id}'`
    );
    await runSql(job,
      `UPDATE ${LIB}.SQLDT00F SET SDSTMT = '${safeStmt}', SDMDTS = ${now} `
      + `WHERE SDUSER = '${user}' AND SDID = '${id}'`
    );

    return res.json({ ok: true });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// DELETE /api/scripts/:id  - soft delete (SHANNL = 'A')
// ---------------------------------------------------------------------------
router.delete('/:id', async (req, res) => {
  const job  = getJob(req);
  if (!job) return res.status(401).json({ error: 'Session expired' });
  const user = req.session.user.padEnd(10);
  const id   = req.params.id;

  try {
    await runSql(job,
      `UPDATE ${LIB}.SQLHD00F SET SHANNL = 'A', SHMDTS = CURRENT_TIMESTAMP `
      + `WHERE SHUSER = '${user}' AND SHID = '${id}'`
    );
    return res.json({ ok: true });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

module.exports = router;
