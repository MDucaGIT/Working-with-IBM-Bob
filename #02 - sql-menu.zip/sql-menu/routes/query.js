// =============================================================================
// routes/query.js - SQL execution and cancel
// POST /api/query/execute  { sql, maxRows }  -> { columns, rows, rowCount }
// POST /api/query/cancel                     -> { ok }
// =============================================================================

'use strict';

const express = require('express');
const router  = express.Router();

// Middleware: require authenticated session
function requireAuth(req, res, next) {
  if (!req.session || !req.session.user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  next();
}

router.use(requireAuth);

// ---------------------------------------------------------------------------
// POST /api/query/execute
// ---------------------------------------------------------------------------
router.post('/execute', async (req, res) => {
  const { sql, maxRows } = req.body;

  if (!sql || !sql.trim()) {
    return res.status(400).json({ error: 'No SQL statement provided' });
  }

  const limit = parseInt(maxRows) > 0 ? parseInt(maxRows) : 200;
  const job   = global.sessionJobs && global.sessionJobs[req.session.id];

  if (!job) {
    return res.status(401).json({ error: 'Session expired, please log in again' });
  }

  // Store a cancellation flag on the job object for this session
  job._cancelRequested = false;

  try {
    const query  = job.query(sql);
    const result = await query.execute(limit);
    await query.close();

    return res.json({
      columns:     result.metadata ? result.metadata.columns.map(c => c.name) : [],
      rows:        result.data     || [],
      rowCount:    result.data     ? result.data.length : 0,
      updateCount: result.update_count ?? null,
    });
  } catch (err) {
    console.error('Query error:', err.message);
    return res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// POST /api/query/cancel
// Closes and re-opens the SQLJob so the current query is aborted.
// The reconnection reuses the credentials stored in the session.
// ---------------------------------------------------------------------------
router.post('/cancel', async (req, res) => {
  const job = global.sessionJobs && global.sessionJobs[req.session.id];
  if (!job) {
    return res.status(401).json({ error: 'No active session' });
  }

  try {
    // Close current job – this aborts any running statement
    const connectOptions = job._connectOptions || {};
    await job.close();

    // Re-open a fresh connection with the same credentials
    if (connectOptions.host && connectOptions.user && connectOptions.password) {
      const { SQLJob } = require('@ibm/mapepire-js');
      const newJob = new SQLJob();
      await newJob.connect(connectOptions);
      newJob._connectOptions = connectOptions;   // carry options forward
      global.sessionJobs[req.session.id] = newJob;
    } else {
      // Cannot reconnect automatically – remove the job; user will need to re-login
      delete global.sessionJobs[req.session.id];
    }

    return res.json({ ok: true });
  } catch (err) {
    console.error('Cancel error:', err.message);
    return res.status(500).json({ error: err.message });
  }
});

module.exports = router;
