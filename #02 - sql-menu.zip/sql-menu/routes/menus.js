// =============================================================================
// routes/menus.js - Manage user menus
//
// GET    /api/menus              -> list all menus for the logged-in user
// GET    /api/menus/:id          -> get one menu with its items
// POST   /api/menus              -> create menu { desc, dscl, items:[{stid,seq}] }
// PUT    /api/menus/:id          -> update menu { desc, dscl, items:[{stid,seq}] }
// DELETE /api/menus/:id          -> soft-delete menu
// =============================================================================

'use strict';

const express = require('express');
const config  = require('../config');
const router  = express.Router();

const LIB = config.db.library;

function requireAuth(req, res, next) {
  if (!req.session || !req.session.user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  next();
}
router.use(requireAuth);

function getJob(req) {
  return global.sessionJobs && global.sessionJobs[req.session.id];
}

async function runSql(job, sql) {
  const q = job.query(sql);
  const r = await q.execute(10000);
  await q.close();
  return r;
}

// ---------------------------------------------------------------------------
// GET /api/menus
// ---------------------------------------------------------------------------
router.get('/', async (req, res) => {
  const job  = getJob(req);
  if (!job) return res.status(401).json({ error: 'Session expired' });
  const user = req.session.user.padEnd(10);

  try {
    const sql = `SELECT MHID, TRIM(MHDESC) AS MHDESC, MHDSCL `
              + `FROM ${LIB}.SQMHD00F `
              + `WHERE MHUSER = '${user}' AND MHANNL = ' ' `
              + `ORDER BY MHDESC`;
    const result = await runSql(job, sql);
    return res.json(result.data || []);
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// GET /api/menus/:id  - menu header + items joined with script description
// ---------------------------------------------------------------------------
router.get('/:id', async (req, res) => {
  const job  = getJob(req);
  if (!job) return res.status(401).json({ error: 'Session expired' });
  const user = req.session.user.padEnd(10);
  const id   = req.params.id;

  try {
    const sqlHd = `SELECT MHID, TRIM(MHDESC) AS MHDESC, MHDSCL `
                + `FROM ${LIB}.SQMHD00F `
                + `WHERE MHUSER = '${user}' AND MHID = '${id}' AND MHANNL = ' '`;

    const sqlDt = `SELECT D.MDSEQ, D.MDSTID, TRIM(H.SHDESC) AS SHDESC, H.SHDSCL `
                + `FROM ${LIB}.SQMDT00F D `
                + `JOIN ${LIB}.SQLHD00F H ON H.SHUSER = D.MDUSER AND H.SHID = D.MDSTID `
                + `WHERE D.MDUSER = '${user}' AND D.MDID = '${id}' `
                + `ORDER BY D.MDSEQ`;

    const [hd, dt] = await Promise.all([runSql(job, sqlHd), runSql(job, sqlDt)]);
    if (!hd.data || hd.data.length === 0) {
      return res.status(404).json({ error: 'Menu not found' });
    }
    return res.json({ ...hd.data[0], items: dt.data || [] });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// POST /api/menus  - create new menu
// ---------------------------------------------------------------------------
router.post('/', async (req, res) => {
  const job  = getJob(req);
  if (!job) return res.status(401).json({ error: 'Session expired' });
  const user  = req.session.user.padEnd(10);
  const { desc, dscl, items } = req.body;

  if (!desc || !desc.trim()) return res.status(400).json({ error: 'Short description required' });

  try {
    const seqResult = await runSql(job, `VALUES (NEXT VALUE FOR ${LIB}.SQMSEQ)`);
    const seqNum    = seqResult.data[0]['00001'];
    const newId     = 'M' + String(seqNum).padStart(9, '0');

    const safeDesc = desc.trim().substring(0, 30).replace(/'/g, "''");
    const safeDscl = (dscl || '').replace(/'/g, "''");
    const now      = 'CURRENT_TIMESTAMP';

    await runSql(job,
      `INSERT INTO ${LIB}.SQMHD00F (MHUSER, MHID, MHDESC, MHDSCL, MHCRTS, MHMDTS, MHANNL) `
      + `VALUES ('${user}', '${newId}', '${safeDesc}', '${safeDscl}', ${now}, ${now}, ' ')`
    );

    if (Array.isArray(items) && items.length > 0) {
      for (const item of items) {
        await runSql(job,
          `INSERT INTO ${LIB}.SQMDT00F (MDUSER, MDID, MDSEQ, MDSTID, MDCRTS, MDMDTS) `
          + `VALUES ('${user}', '${newId}', ${item.seq}, '${item.stid}', ${now}, ${now})`
        );
      }
    }

    return res.status(201).json({ id: newId });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// PUT /api/menus/:id  - replace menu items and update header
// ---------------------------------------------------------------------------
router.put('/:id', async (req, res) => {
  const job  = getJob(req);
  if (!job) return res.status(401).json({ error: 'Session expired' });
  const user  = req.session.user.padEnd(10);
  const id    = req.params.id;
  const { desc, dscl, items } = req.body;

  if (!desc || !desc.trim()) return res.status(400).json({ error: 'Short description required' });

  try {
    const safeDesc = desc.trim().substring(0, 30).replace(/'/g, "''");
    const safeDscl = (dscl || '').replace(/'/g, "''");
    const now      = 'CURRENT_TIMESTAMP';

    await runSql(job,
      `UPDATE ${LIB}.SQMHD00F SET MHDESC = '${safeDesc}', MHDSCL = '${safeDscl}', MHMDTS = ${now} `
      + `WHERE MHUSER = '${user}' AND MHID = '${id}'`
    );

    // Replace all items
    await runSql(job,
      `DELETE FROM ${LIB}.SQMDT00F WHERE MDUSER = '${user}' AND MDID = '${id}'`
    );

    if (Array.isArray(items) && items.length > 0) {
      for (const item of items) {
        await runSql(job,
          `INSERT INTO ${LIB}.SQMDT00F (MDUSER, MDID, MDSEQ, MDSTID, MDCRTS, MDMDTS) `
          + `VALUES ('${user}', '${id}', ${item.seq}, '${item.stid}', ${now}, ${now})`
        );
      }
    }

    return res.json({ ok: true });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// DELETE /api/menus/:id  - soft delete
// ---------------------------------------------------------------------------
router.delete('/:id', async (req, res) => {
  const job  = getJob(req);
  if (!job) return res.status(401).json({ error: 'Session expired' });
  const user = req.session.user.padEnd(10);
  const id   = req.params.id;

  try {
    await runSql(job,
      `UPDATE ${LIB}.SQMHD00F SET MHANNL = 'A', MHMDTS = CURRENT_TIMESTAMP `
      + `WHERE MHUSER = '${user}' AND MHID = '${id}'`
    );
    return res.json({ ok: true });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

module.exports = router;
