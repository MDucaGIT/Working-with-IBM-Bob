# SQL Menu — Installation Guide for IBM i

## Prerequisites

| Requirement | Notes |
|---|---|
| IBM i 7.4 or higher | Tested on 7.4 / 7.5 |
| Node.js >= 18 on IBM i | Install via IBM i Open Source (yum) |
| Mapepire Server | Already installed on the system |
| Library `<MYLIB>` exists | Must be created before running the DDL |

### Frontend libraries (loaded from CDN — no installation required)

| Library | Version | Purpose |
|---|---|---|
| [Bootstrap](https://getbootstrap.com/) | 5.3 | UI layout, modals, buttons |
| [Bootstrap Icons](https://icons.getbootstrap.com/) | 1.11 | Icon set |
| [Tabulator](https://tabulator.info/) | 6.2 | Interactive results grid (sorting, column resize, row selection, copy to clipboard) |

> The browser loads these libraries directly from CDN at runtime.
> No internet access is required on the IBM i server itself.

---

## Step 1 — Create the library and tables on IBM i

Open ACS Run SQL Scripts (or any SQL client) and run:

```sql
CREATE SCHEMA <MYLIB>;
```

Then execute the full content of `crtDB.sql` (located in the project root,
one level above `sql-menu/`).

---

## Step 2 — Copy the application to the IFS

Copy the `sql-menu` folder to the IBM i IFS at:

```
/home/<MYUSER>/nodeApps/sql-menu/
```

Use ACS Integrated File System, FTP, or scp.
The expected structure on the IFS:

```
/home/<MYUSER>/nodeApps/sql-menu/
  config.js
  server.js
  package.json
  NODE001.clle
  routes/
    auth.js  query.js  scripts.js  menus.js  settings.js
  public/
    login.html  index.html  manage-scripts.html  manage-menus.html
    js/
      app.js
```

---

## Step 3 — Install Node.js dependencies

Open a PASE shell (QSH, ssh, or ACS Open Terminal) and run:

```bash
export PATH=/QOpenSys/pkgs/bin:$PATH
cd /home/<MYUSER>/nodeApps/sql-menu
npm install
```

This installs `express`, `express-session`, and `@ibm/mapepire-js`
into the local `node_modules` folder. No administrator rights required.

---

## Step 4 — Configuration (optional overrides)

Edit `config.js` directly, or set environment variables before starting.

| Variable | Default | Description |
|---|---|---|
| `IBMI_HOST` | `localhost` | Mapepire server hostname |
| `IBMI_PORT` | `8076` | Mapepire server port |
| `APP_LIBRARY` | `<MYLIB>` | Library containing the application tables |
| `PORT` | `3301` | HTTP port the app listens on |
| `SESSION_SECRET` | (built-in) | Change this for production! |
| `APP_BASE_PATH` | `/home/<MYUSER>/nodeApps/sql-menu` | IFS base path of the app |

If Mapepire runs on the same IBM i partition, `localhost` is correct.

---

## Step 5A — Start from PASE shell

```bash
export PATH=/QOpenSys/pkgs/bin:$PATH
cd /home/<MYUSER>/nodeApps/sql-menu
node server.js
```

You should see:

```
sql-menu running on port 3301
```

Open a browser and go to:  `http://<ibmi-hostname>:3301`

---

## Step 5B — Start via CL program NODE001 (alternative)

Compile the CL source on IBM i:

```
CRTSRCPF FILE(<MYLIB>/QCLLESRC) RCDLEN(112)
```

Copy `NODE001.clle` into member `NODE001` of `<MYLIB>/QCLLESRC`
(use ACS IFS or FTP in text mode), then compile:

```
CRTBNDCL PGM(<MYLIB>/NODE001) SRCFILE(<MYLIB>/QCLLESRC) SRCMBR(NODE001)
```

**Run interactively** (the job stays attached to your session):

```
CALL PGM(<MYLIB>/NODE001)
```

**Run in batch** (recommended for production — the app keeps running
even after you sign off):

```
SBMJOB CMD(CALL PGM(<MYLIB>/NODE001)) JOB(SQLMENU) +
       JOBD(QBATCH) USER(<MYUSER>) INLLIBL(*JOBD)
```

Application log is written to:
```
/home/<MYUSER>/nodeApps/sql-menu/sql-menu.log
```

To stop the batch job:

```
ENDJOB JOB(SQLMENU) OPTION(*CNTRLD) DELAY(10)
```

---

## Step 6 — Settings folder (auto-created)

The per-user settings directory is created automatically at first save:

```
/home/<MYUSER>/nodeApps/sql-menu/settings/
  <MYUSER>.json
  OTHERUSER.json
```

No manual creation needed.

---

## Troubleshooting

| Symptom | Likely cause |
|---|---|
| Login returns "Invalid username or password" | Mapepire not running, or wrong host/port in `config.js` |
| `Cannot find module '@ibm/mapepire-js'` | `npm install` was not run |
| Tables not found on first use | `crtDB.sql` not executed, or wrong library name |
| Port 3301 already in use | Change `PORT` env variable or edit `config.js` |
| Node not found in CL | Node.js not installed via yum, or PATH wrong in `NODE001.clle` |
