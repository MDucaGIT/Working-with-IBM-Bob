-- =============================================================================
-- create-tables.sql DDL SQL Menu su IBM i (libreria TESDUM9062)
-- Eseguire tramite: node db/init-db.js
-- Compatibile con IBM i 7.4 e superiori.
-- Ogni statement è separato da un punto e virgola su riga propria.
-- =============================================================================


-- -----------------------------------------------------------------------------
-- SEQUENCE generatori ID progressivi
-- NO CACHE ORDER: ordine stretto garantito, nessun salto dopo restart IBM i
-- -----------------------------------------------------------------------------

CREATE SEQUENCE SQLSEQ
  START WITH 1
  INCREMENT BY 1
  MINVALUE 1
  MAXVALUE 999999999
  NO CYCLE
  NO CACHE
  ORDER
;

CREATE SEQUENCE SQMSEQ
  START WITH 1
  INCREMENT BY 1
  MINVALUE 1
  MAXVALUE 999999999
  NO CYCLE
  NO CACHE
  ORDER
;


-- -----------------------------------------------------------------------------
-- SQLHD00F - Testata statement SQL
-- PK: (SHUSER, SHID)
-- ID formato: S000000001 - S999999999 (generato da SQLSEQ lato Node.js)
-- SHANNL: ' ' = attivo, 'A' = eliminato (soft delete)
-- -----------------------------------------------------------------------------

CREATE TABLE SQLHD00F (
  SHUSER  CHAR(10)      NOT NULL DEFAULT '',
  SHID    CHAR(10)      NOT NULL DEFAULT '',
  SHDESC  CHAR(30)      NOT NULL DEFAULT '',
  SHDSCL  VARCHAR(250)  NOT NULL DEFAULT '',
  SHCRTS  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  SHMDTS  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  SHANNL  CHAR(1)       NOT NULL DEFAULT ' ',
  CONSTRAINT SQLHD00F_PK PRIMARY KEY (SHUSER, SHID)
)
;

LABEL ON TABLE SQLHD00F
  IS 'Testata statement SQL'
;

LABEL ON COLUMN SQLHD00F (
  SHUSER  IS 'Utente IBM i ',
  SHID    IS 'ID statement ',
  SHDESC  IS 'Descrizione breve ',
  SHDSCL  IS 'Descrizione estesa ',
  SHCRTS  IS 'Timestamp creazione',
  SHMDTS  IS 'Timestamp ultima modifica',
  SHANNL  IS 'Stato: A=eliminato'
)
;


-- -----------------------------------------------------------------------------
-- SQLDT00F - Dettaglio statement SQL (testo completo)
-- PK: (SDUSER, SDID)  - relazione 1:1 con SQLHD00F
-- SDSTMT: CLOB(1M) - testo salvato esattamente come scritto dall'utente
-- -----------------------------------------------------------------------------

CREATE TABLE SQLDT00F (
  SDUSER  CHAR(10)          NOT NULL DEFAULT '',
  SDID    CHAR(10)          NOT NULL DEFAULT '',
  SDSTMT  CLOB(1048576)     NOT NULL DEFAULT '',
  SDCRTS  TIMESTAMP         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  SDMDTS  TIMESTAMP         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT SQLDT00F_PK PRIMARY KEY (SDUSER, SDID)
)
;

LABEL ON TABLE SQLDT00F
  IS 'Dettaglio statement SQL - testo completo'
;

LABEL ON COLUMN SQLDT00F (
  SDUSER  IS 'Utente IBM i ',
  SDID    IS 'ID statement ',
  SDSTMT  IS 'Statement SQL ',
  SDCRTS  IS 'Timestamp creazione',
  SDMDTS  IS 'Timestamp ultima modifica'
)
;


-- -----------------------------------------------------------------------------
-- SQMHD00F - Testata menù
-- PK: (MHUSER, MHID)
-- ID formato: M000000001 - M999999999 (generato da SQMSEQ lato Node.js)
-- MHANNL: ' ' = attivo, 'A' = eliminato (soft delete)
-- -----------------------------------------------------------------------------

CREATE TABLE SQMHD00F (
  MHUSER  CHAR(10)      NOT NULL DEFAULT '',
  MHID    CHAR(10)      NOT NULL DEFAULT '',
  MHDESC  CHAR(30)      NOT NULL DEFAULT '',
  MHDSCL  VARCHAR(250)  NOT NULL DEFAULT '',
  MHCRTS  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  MHMDTS  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  MHANNL  CHAR(1)       NOT NULL DEFAULT ' ',
  CONSTRAINT SQMHD00F_PK PRIMARY KEY (MHUSER, MHID)
)
;

LABEL ON TABLE SQMHD00F
  IS 'Testata menu SQL'
;

LABEL ON COLUMN SQMHD00F (
  MHUSER  IS 'Utente IBM i ',
  MHID    IS 'ID menu ',
  MHDESC  IS 'Descrizione breve',
  MHDSCL  IS 'Descrizione estesa ',
  MHCRTS  IS 'Timestamp creazione',
  MHMDTS  IS 'Timestamp ultima modifica',
  MHANNL  IS 'Stato: A=eliminato'
)
;


-- -----------------------------------------------------------------------------
-- SQMDT00F - Dettaglio menù (voci / statement associati)
-- PK: (MDUSER, MDID, MDSEQ)
-- MDSEQ multipli di 10: lascia margine per inserimenti futuri senza riordinare
-- FK logica (MDUSER, MDSTID) - (SHUSER, SHID): garantita lato applicazione
-- -----------------------------------------------------------------------------

CREATE TABLE SQMDT00F (
  MDUSER  CHAR(10)      NOT NULL DEFAULT '',
  MDID    CHAR(10)      NOT NULL DEFAULT '',
  MDSEQ   DECIMAL(5, 0) NOT NULL DEFAULT 0,
  MDSTID  CHAR(10)      NOT NULL DEFAULT '',
  MDCRTS  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  MDMDTS  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT SQMDT00F_PK PRIMARY KEY (MDUSER, MDID, MDSEQ)
)
;

LABEL ON TABLE SQMDT00F
  IS 'Dettaglio menu - voci e statement associati'
;

LABEL ON COLUMN SQMDT00F (
  MDUSER  IS 'Utente IBM i ',
  MDID    IS 'ID menu di appartenenza',
  MDSEQ   IS 'Numero sequenza voce ',
  MDSTID  IS 'ID statement associato - SQLHD00F',
  MDCRTS  IS 'Timestamp creazione',
  MDMDTS  IS 'Timestamp ultima modifica'
)
;
