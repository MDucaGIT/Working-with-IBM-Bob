// =============================================================================
// config.js - Application configuration
// Deploy path on IBM i: /home/MDUCA/nodeApps/sql-menu
// =============================================================================

module.exports = {
  // IBM i Mapepire connection (host/port are read from environment or defaults)
  mapepire: {
    host: process.env.IBMI_HOST || 'localhost',
    port: parseInt(process.env.IBMI_PORT || '8076'),
    // Credentials are supplied at runtime from the login form (per-session)
    // Self-signed certificate on IBM i Mapepire: disable TLS verification
    ignoreUnauthorized: (process.env.IBMI_IGNORE_TLS || 'true') === 'true',
  },

  // Library that holds the application tables (SQLHD00F, SQLDT00F, SQMHD00F, SQMDT00F)
  db: {
    library: process.env.APP_LIBRARY || 'MDUCA1',
  },

  // Express session
  session: {
    secret:            process.env.SESSION_SECRET || 'sql-menu-secret-change-me',
    resave:            false,
    saveUninitialized: false,
    cookie: {
      // 8-hour session
      maxAge: 8 * 60 * 60 * 1000,
    },
  },

  // HTTP server
  server: {
    port: parseInt(process.env.PORT || '3301'),
  },

  // Base path of the application on the IFS (used to resolve per-user settings files)
  appBasePath: process.env.APP_BASE_PATH || '/home/MDUCA/nodeApps/sql-menu',
};
